package com.kgfsl.fixme.aspect;
import com.kgfsl.fixme.model.Sample;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.aspectj.lang.reflect.SourceLocation;

//@Aspect
//@Component
public class SampleServiceAspect {
    private static final Logger LOGGER = LoggerFactory.getLogger(SampleServiceAspect.class);
      @Pointcut("execution(* com.abc.xyz.content.service..*(..))")
    protected void loggingOperation()
    {
    }

//within(com.howtodoinjava..*)
    @Before("execution(* com.kgfsl.fixme..service.*.*(..))")
    public void beforeSampleCreation(JoinPoint joinPoint) {
        LOGGER.info("A request was issued for a sample name: "+ joinPoint.getSourceLocation());
    }
    @Around("execution(* com.kgfsl.fixme..service.*.*(..))")
    public Object aroundSampleCreation(ProceedingJoinPoint proceedingJoinPoint,String sampleName) throws Throwable {
        LOGGER.info("A request was issued for a sample name: "+sampleName);
        sampleName = sampleName+"!";
        Sample sample = (Sample) proceedingJoinPoint.proceed(new Object[] {sampleName});
        sample.setName(sample.getName().toUpperCase());
        return sample;
    }

}
