package com.kgfsl.fixme.service;
import com.kgfsl.fixme.model.Sample;
import org.springframework.stereotype.Service;

@Service
public class SampleService {
    public Sample createSample(String sampleName) {
        Sample sample = new Sample();
        sample.setName(sampleName);
        return sample;
    }

        public Sample updateSample(String sampleName) {
        Sample sample = new Sample();
        sample.setName(sampleName);
        return sample;
    }
}
